import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Food-Waste-Management",
  description: "AI-powered waste management platform",
}